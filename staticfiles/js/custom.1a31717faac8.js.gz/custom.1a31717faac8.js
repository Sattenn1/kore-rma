$(document).ready(function () {
    $('#download').click(function () {
      html2canvas(document.querySelector('#frame'))
    });
  
});
  

